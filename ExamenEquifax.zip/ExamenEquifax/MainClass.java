import reader.CommandReader;

import java.util.ArrayList;
import java.util.List;
import commandexecutor.Command;
import commandexecutor.Dependency;
import exceptions.MyExecException;

public class MainClass
{
	public static void main (String [] args){
		List <String> programsList = new ArrayList();
		List <Dependency> dependenciesList = new ArrayList();

		try{
		List <Command> commands = CommandReader.readCommands();
		for(Command c: commands)
			c.process(programsList, dependenciesList);
		}
		catch(MyExecException e){
			System.out.println("Error while executing program: " + e.getMessage());
		}
	}
}