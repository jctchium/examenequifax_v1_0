package commandexecutor;

import java.util.ArrayList;
import java.util.List;
import exceptions.CommandValidatorException;

public class CommandValidator{
	public static Command validateCommand(String line) throws CommandValidatorException{
		if(line.length() > 80)
			throw new CommandValidatorException("line " + line + " has more than 80 characters");

		String lineTrimed = line.trim();

		int stringLength = lineTrimed.length();
		int start = 0;
		int end = 0;
		String sTemp;
		List <String> wordsList = new ArrayList();

		for(int i = 0; i < stringLength; i++){
			if(lineTrimed.charAt(i) == 32){
				sTemp = lineTrimed.substring(start, end);
				start = i + 1;
				end = i + 1;
				wordsList.add(sTemp);
			}
			else{
				end++;
			}

			if(i == (stringLength - 1)){
				sTemp = lineTrimed.substring(start, end);
				start = i + 1;
				end = i + 1;
				wordsList.add(sTemp);
			}
		}

		//System.out.println("line " + lineTrimed);
		//System.out.println(wordsList.size());

		if(wordsList.size() > 0)
		{
			if(wordsList.get(0).equals("LIST"))
				return new ListCommand("LIST", new String[0]);
			else if(wordsList.get(0).equals("INSTALL")){
				if(wordsList.size() == 2){
					String [] array = new String[1];
					array[0] = wordsList.get(1);
					return new InstallCommand("INSTALL", array);
				}
			}
			else if(wordsList.get(0).equals("REMOVE")){
				if(wordsList.size() == 2){
					String [] array = new String[1];
					array[0] = wordsList.get(1);
					return new RemoveCommand("REMOVE", array);
				}
			}
			else
				throw new CommandValidatorException("command \"" + wordsList.get(0) + "\" not recognized");
		}
		else
			throw new CommandValidatorException("command not recognized");

		return new ListCommand("LIST", new String[0]);
	}
}