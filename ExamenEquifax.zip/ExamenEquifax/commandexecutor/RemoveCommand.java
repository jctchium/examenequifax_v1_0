package commandexecutor;

import java.util.List;

public class RemoveCommand extends Command{
	public RemoveCommand(String sentence, String [] body){
		super.sentence = sentence;
		super.body = body;
	}

	public void process(List <String> listaProgramas, List <Dependency> dependencyList){
		StringBuffer buffer = new StringBuffer(sentence);
		for(String s: body){
			buffer.append(" ");
			buffer.append(s);
		}

		System.out.println(buffer.toString());

		if(!listaProgramas.contains(body[0])){
			System.out.println("Program " + body[0] + " not installed");
		}
		else{
			listaProgramas.remove(body[0]);
			System.out.println("Deleting " + body[0]);
		}

		//System.out.println(listaProgramas.size());
	}
}