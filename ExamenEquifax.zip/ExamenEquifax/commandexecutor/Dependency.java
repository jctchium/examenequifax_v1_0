package commandexecutor;

public class Dependency{
	private String programMandatory;
	private String programDepending;

	public Dependency(String programMandatory, String programDepending){
		this.programMandatory = programMandatory;
		this.programDepending = programDepending;
	}

	public String getProgramMandatory(){
		return this.programMandatory;
	}

	public String getProgramDepending(){
		return this.programDepending;
	}
}