package commandexecutor;

import java.util.List;

public class InstallCommand extends Command{
	public InstallCommand(String sentence, String [] body){
		super.sentence = sentence;
		super.body = body;
	}

	public void process(List <String> listaProgramas, List <Dependency> dependencyList){
		StringBuffer buffer = new StringBuffer(sentence);
		for(String s: body){
			buffer.append(" ");
			buffer.append(s);
		}

		System.out.println(buffer.toString());

		if(listaProgramas.contains(body[0])){
			System.out.println("Program " + body[0] + " already installed");
		}
		else{
			listaProgramas.add(body[0]);
			System.out.println("Installing " + body[0]);
		}

		//System.out.println(listaProgramas.size());
	}
}