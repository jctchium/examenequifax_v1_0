package commandexecutor;

import java.util.List;

public class ListCommand extends Command{
	public ListCommand(String sentence, String [] body){
		super.sentence = sentence;
		super.body = body;
	}

	public void process(List <String> listaProgramas, List <Dependency> dependencyList){
		StringBuffer buffer = new StringBuffer(sentence);
		for(String s: body){
			buffer.append(" ");
			buffer.append(s);
		}

		System.out.println(buffer.toString());

		for(String s: listaProgramas){
			System.out.println(s);
		}
	}
}