package exceptions;

public class CommandValidatorException extends Exception{
	String message;

	public CommandValidatorException(String message){
		this.message = message;
	}

	public String getMessage(){
		return this.message;
	}
}
